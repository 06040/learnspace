package com.example.service;

import com.example.entity.Role;
import com.example.entity.UserAccount;
import com.example.repository.RoleRepository;
import com.example.repository.UserAccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserAccountRepository users;
    private final RoleRepository roles;
    private final PasswordEncoder passwordEncoder;
    private final ActivityLogService audit;

    @Transactional(readOnly = true)
    public UserAccount current(Authentication authentication) {
        return users.findByUsername(authentication.getName())
                .orElseThrow(() -> new IllegalStateException("Current user not found"));
    }

    @Transactional(readOnly = true)
    public List<UserAccount> all() {
        return users.findAll();
    }

    @Transactional
    public UserAccount registerStudent(String username, String email, String password, String fullName) {
        if (users.existsByUsername(username) || users.existsByEmail(email)) {
            throw new IllegalArgumentException("Пользователь с таким логином или email уже существует");
        }
        Role role = roles.findByName("STUDENT").orElseThrow();
        UserAccount user = UserAccount.builder()
                .username(username)
                .email(email)
                .password(passwordEncoder.encode(password))
                .fullName(fullName)
                .enabled(true)
                .build();
        user.getRoles().add(role);
        return users.save(user);
    }

    @Transactional
    public UserAccount createTeacher(String username, String email, String password, String fullName, UserAccount admin) {
        if (users.existsByUsername(username) || users.existsByEmail(email)) {
            throw new IllegalArgumentException("Пользователь с таким логином или email уже существует");
        }
        Role role = roles.findByName("TEACHER").orElseThrow();
        UserAccount teacher = UserAccount.builder()
                .username(username)
                .email(email)
                .password(passwordEncoder.encode(password))
                .fullName(fullName)
                .enabled(true)
                .build();
        teacher.getRoles().add(role);
        UserAccount saved = users.save(teacher);
        audit.record(admin, "CREATE", "USER", saved.getId(), "Создан преподаватель: " + saved.getUsername());
        return saved;
    }
}
