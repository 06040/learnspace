package com.example.service;

import com.example.entity.ActivityLog;
import com.example.entity.UserAccount;
import com.example.repository.ActivityLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ActivityLogService {
    private final ActivityLogRepository repository;

    @Transactional
    public void record(UserAccount actor, String action, String targetType, Long targetId, String details) {
        repository.save(ActivityLog.builder()
                .actor(actor)
                .action(action)
                .targetType(targetType)
                .targetId(targetId)
                .details(details)
                .createdAt(LocalDateTime.now())
                .build());
    }

    @Transactional(readOnly = true)
    public List<ActivityLog> latest() {
        return repository.findTop50ByOrderByCreatedAtDesc();
    }
}
