package com.example.service;

import com.example.entity.ScheduleEvent;
import com.example.entity.UserAccount;
import com.example.repository.ScheduleEventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ScheduleService {
    private final ScheduleEventRepository schedules;
    private final ActivityLogService audit;

    @Transactional(readOnly = true)
    public List<ScheduleEvent> all() {
        return schedules.findAllByOrderByStartsAtAsc();
    }

    @Transactional(readOnly = true)
    public List<ScheduleEvent> byOwner(UserAccount owner) {
        return schedules.findByOwnerIdOrderByStartsAtAsc(owner.getId());
    }

    @Transactional(readOnly = true)
    public ScheduleEvent get(Long id) {
        return schedules.findById(id).orElseThrow();
    }

    @Transactional
    public ScheduleEvent save(Long id, String heading, String notes, String place, String speaker,
                              LocalDateTime startsAt, LocalDateTime endsAt, UserAccount owner, UserAccount actor) {
        ScheduleEvent event = id == null ? new ScheduleEvent() : schedules.findById(id).orElseThrow();
        event.setHeading(heading);
        event.setNotes(notes);
        event.setPlace(place);
        event.setSpeaker(speaker);
        event.setStartsAt(startsAt);
        event.setEndsAt(endsAt);
        if (event.getOwner() == null) {
            event.setOwner(owner);
        }
        ScheduleEvent saved = schedules.save(event);
        audit.record(actor, id == null ? "CREATE" : "UPDATE", "SCHEDULE", saved.getId(), "Расписание: " + saved.getHeading());
        return saved;
    }

    @Transactional
    public void delete(Long id, UserAccount actor) {
        ScheduleEvent event = schedules.findById(id).orElseThrow();
        schedules.delete(event);
        audit.record(actor, "DELETE", "SCHEDULE", id, "Удалено событие: " + event.getHeading());
    }
}
