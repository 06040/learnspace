package com.example.service;

import com.example.entity.Course;
import com.example.entity.Enrollment;
import com.example.entity.UserAccount;
import com.example.enums.EnrollmentState;
import com.example.repository.CourseRepository;
import com.example.repository.EnrollmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CourseService {
    private final CourseRepository courses;
    private final EnrollmentRepository enrollments;
    private final ActivityLogService audit;

    @Transactional(readOnly = true)
    public List<Course> published() {
        return courses.findByPublishedTrue(PageRequest.of(0, 100)).getContent();
    }

    @Transactional(readOnly = true)
    public List<Course> all() {
        return courses.findAllByOrderByCreatedAtDesc();
    }

    @Transactional(readOnly = true)
    public List<Course> byTeacher(UserAccount teacher) {
        return courses.findByTeacherId(teacher.getId(), PageRequest.of(0, 100)).getContent();
    }

    @Transactional(readOnly = true)
    public Course get(Long id) {
        return courses.findWithModulesById(id).orElseThrow();
    }

    @Transactional
    public Course save(Long id, String title, String summary, String description, String category,
                       String difficulty, Integer durationHours, boolean published, UserAccount teacher, UserAccount actor) {
        Course course = id == null ? new Course() : courses.findById(id).orElseThrow();
        course.setTitle(title);
        course.setSummary(summary);
        course.setDescription(description);
        course.setCategory(category);
        course.setDifficulty(difficulty);
        course.setDurationHours(durationHours);
        course.setPublished(published);
        if (course.getTeacher() == null) {
            course.setTeacher(teacher);
        }
        Course saved = courses.save(course);
        audit.record(actor, id == null ? "CREATE" : "UPDATE", "COURSE", saved.getId(), "Курс: " + saved.getTitle());
        return saved;
    }

    @Transactional
    public void delete(Long id, UserAccount actor) {
        Course course = courses.findById(id).orElseThrow();
        courses.delete(course);
        audit.record(actor, "DELETE", "COURSE", id, "Удалён курс: " + course.getTitle());
    }

    @Transactional
    public void enroll(UserAccount student, Long courseId) {
        Course course = courses.findById(courseId).orElseThrow();
        enrollments.findByStudentIdAndCourseId(student.getId(), courseId).orElseGet(() ->
                enrollments.save(Enrollment.builder()
                        .student(student)
                        .course(course)
                        .status(EnrollmentState.ACTIVE)
                        .build()));
    }

    @Transactional(readOnly = true)
    public List<Enrollment> studentEnrollments(UserAccount student) {
        return enrollments.findByStudentId(student.getId());
    }

    @Transactional(readOnly = true)
    public List<Enrollment> enrollmentsForTeacher(UserAccount teacher) {
        return enrollments.findByCourseTeacherIdOrderByCourseTitleAscStudentFullNameAsc(teacher.getId());
    }
}
