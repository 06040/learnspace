package com.example.mapper;
import com.example.dto.LessonDto;
import com.example.entity.Lesson;
import org.mapstruct.*;
@Mapper(componentModel = "spring")
public interface LessonMapper {
    @Mapping(target = "assignments", ignore = true)
    @Mapping(target = "completed", constant = "false")
    LessonDto toDto(Lesson lesson);
}
