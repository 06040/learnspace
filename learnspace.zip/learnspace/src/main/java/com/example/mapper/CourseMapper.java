package com.example.mapper;
import com.example.dto.*;
import com.example.entity.Course;
import org.mapstruct.*;
@Mapper(componentModel = "spring", uses = {LessonMapper.class})
public interface CourseMapper {
    @Mapping(target = "moduleCount", source = "modules", qualifiedByName = "countModules")
    @Mapping(target = "studentCount", source = "enrollments", qualifiedByName = "countEnrollments")
    @Mapping(target = "teacherName", source = "teacher.fullName")
    CourseSummaryDto toSummary(Course course);
    @Mapping(target = "teacher", source = "teacher", qualifiedByName = "toTeacherBrief")
    @Mapping(target = "modules", source = "modules")
    CourseDetailDto toDetail(Course course);
    @Named("countModules")
    default int countModules(java.util.List<?> modules) { return modules == null ? 0 : modules.size(); }
    @Named("countEnrollments")
    default int countEnrollments(java.util.List<?> enrollments) { return enrollments == null ? 0 : enrollments.size(); }
    @Named("toTeacherBrief")
    default TeacherBriefDto toTeacherBrief(com.example.entity.UserAccount u) {
        if (u == null) return null;
        return TeacherBriefDto.builder().id(u.getId()).fullName(u.getFullName())
            .avatarUrl(u.getAvatarUrl()).bio(u.getBio()).build();
    }
}
