package com.example.mapper;
import com.example.dto.ScheduleEventDto;
import com.example.entity.ScheduleEvent;
import org.mapstruct.*;
@Mapper(componentModel = "spring")
public interface ScheduleMapper {
    ScheduleEventDto toDto(ScheduleEvent event);
}
