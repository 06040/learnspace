package com.example.mapper;
import com.example.dto.EnrollmentProgressDto;
import com.example.entity.*;
import org.mapstruct.*;
@Mapper(componentModel = "spring")
public interface EnrollmentMapper {
    @Mapping(target = "courseId", source = "course.id")
    @Mapping(target = "courseTitle", source = "course.title")
    @Mapping(target = "coverImage", source = "course.coverImage")
    @Mapping(target = "totalLessons", source = "course", qualifiedByName = "countAllLessons")
    @Mapping(target = "completedLessons", source = "progressEntries", qualifiedByName = "countCompleted")
    @Mapping(target = "percent", source = ".", qualifiedByName = "calcPercent")
    @Mapping(target = "enrolledAt", source = "createdAt")
    EnrollmentProgressDto toProgressDto(Enrollment enrollment);
    @Named("countAllLessons")
    default int countAllLessons(com.example.entity.Course course) {
        if (course.getModules() == null) return 0;
        return course.getModules().stream()
            .mapToInt(m -> m.getLessons() == null ? 0 : m.getLessons().size()).sum();
    }
    @Named("countCompleted")
    default int countCompleted(java.util.List<LessonProgress> entries) {
        if (entries == null) return 0;
        return (int) entries.stream().filter(LessonProgress::isCompleted).count();
    }
    @Named("calcPercent")
    default int calcPercent(Enrollment e) {
        int total = countAllLessons(e.getCourse());
        if (total == 0) return 0;
        int done = countCompleted(e.getProgressEntries());
        return (int) Math.round((double) done * 100 / total);
    }
}
