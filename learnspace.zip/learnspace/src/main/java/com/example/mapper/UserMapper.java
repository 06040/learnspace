package com.example.mapper;
import com.example.dto.*;
import com.example.entity.*;
import org.mapstruct.*;
import java.util.stream.Collectors;
@Mapper(componentModel = "spring")
public interface UserMapper {
    @Mapping(target = "roles", expression = "java(mapRoles(user))")
    UserSummaryDto toSummary(UserAccount user);
    default java.util.Set<String> mapRoles(UserAccount user) {
        if (user.getRoles() == null) return java.util.Collections.emptySet();
        return user.getRoles().stream().map(Role::getName).collect(Collectors.toSet());
    }
}
