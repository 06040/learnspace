package com.example.mapper;
import com.example.dto.*;
import com.example.entity.*;
import org.mapstruct.*;
@Mapper(componentModel = "spring")
public interface AssignmentMapper {
    @Mapping(target = "courseTitle", source = "course.title")
    @Mapping(target = "questions", source = "questions")
    @Mapping(target = "submitted", constant = "false")
    @Mapping(target = "earnedPoints", ignore = true)
    @Mapping(target = "submissionState", ignore = true)
    AssignmentDetailDto toDetail(Assignment assignment);
    AssignmentSummaryDto toSummary(Assignment assignment);
    @Mapping(target = "assignmentId", source = "assignment.id")
    @Mapping(target = "assignmentTitle", source = "assignment.title")
    @Mapping(target = "studentId", source = "student.id")
    @Mapping(target = "studentName", source = "student.fullName")
    @Mapping(target = "maxPoints", source = "assignment.maxPoints")
    SubmissionDto toSubmissionDto(AssignmentSubmission submission);
    QuestionDto toQuestionDto(TestQuestion question);
    OptionDto toOptionDto(AnswerOption option);
}
