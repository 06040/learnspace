package com.example.entity;
import jakarta.persistence.*;
import lombok.*;
import java.util.ArrayList;
import java.util.List;
@Entity @Table(name = "course_modules")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class CourseModule extends BaseEntity {
    @Column(nullable = false, length = 200) private String title;
    @Column(columnDefinition = "text") private String description;
    @Column(nullable = false) private Integer ordering;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "course_id", nullable = false) private Course course;
    @OneToMany(mappedBy = "module", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("ordering ASC")
    @Builder.Default private List<Lesson> lessons = new ArrayList<>();
}