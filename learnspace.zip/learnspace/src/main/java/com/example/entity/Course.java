package com.example.entity;
import jakarta.persistence.*;
import lombok.*;
import java.util.ArrayList;
import java.util.List;
@Entity @Table(name = "courses")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Course extends BaseEntity {
    @Column(nullable = false, length = 200) private String title;
    @Column(length = 500) private String summary;
    @Column(columnDefinition = "text") private String description;
    @Column(name = "cover_image", length = 500) private String coverImage;
    @Column(length = 20) private String difficulty;
    @Column(name = "duration_hours") private Integer durationHours;
    @Column(nullable = false) @Builder.Default private boolean published = false;
    @Column(length = 80) private String category;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "teacher_id", nullable = false) private UserAccount teacher;
    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("ordering ASC")
    @Builder.Default private List<CourseModule> modules = new ArrayList<>();
    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default private List<Enrollment> enrollments = new ArrayList<>();
}