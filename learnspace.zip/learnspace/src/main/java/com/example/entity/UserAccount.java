package com.example.entity;
import jakarta.persistence.*;
import lombok.*;
import java.util.HashSet;
import java.util.Set;
@Entity @Table(name = "users")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class UserAccount extends BaseEntity {
    @Column(nullable = false, unique = true, length = 50) private String username;
    @Column(nullable = false, unique = true, length = 120) private String email;
    @Column(nullable = false) private String password;
    @Column(name = "full_name", length = 150) private String fullName;
    @Column(columnDefinition = "text") private String bio;
    @Column(name = "avatar_url", length = 500) private String avatarUrl;
    @Column(nullable = false) @Builder.Default private boolean enabled = true;
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "user_roles", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "role_id"))
    @Builder.Default private Set<Role> roles = new HashSet<>();
}
