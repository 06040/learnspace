package com.example.entity;
import com.example.enums.EnrollmentState;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
@Entity @Table(name = "enrollments", uniqueConstraints = @UniqueConstraint(columnNames = {"student_id", "course_id"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Enrollment extends BaseEntity {
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 20) @Builder.Default private EnrollmentState status = EnrollmentState.ACTIVE;
    @Column(name = "completed_at") private LocalDateTime completedAt;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "student_id", nullable = false) private UserAccount student;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "course_id", nullable = false) private Course course;
    @OneToMany(mappedBy = "enrollment", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default private List<LessonProgress> progressEntries = new ArrayList<>();
}