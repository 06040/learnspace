package com.example.entity;
import com.example.enums.QuestionKind;
import jakarta.persistence.*;
import lombok.*;
import java.util.ArrayList;
import java.util.List;
@Entity @Table(name = "test_questions")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class TestQuestion extends BaseEntity {
    @Column(nullable = false, columnDefinition = "text") private String prompt;
    @Enumerated(EnumType.STRING) @Column(name = "question_type", nullable = false, length = 30) private QuestionKind questionType;
    @Column(nullable = false) @Builder.Default private Integer points = 1;
    @Column(nullable = false) @Builder.Default private Integer ordering = 0;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "assignment_id", nullable = false) private Assignment assignment;
    @OneToMany(mappedBy = "question", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("ordering ASC")
    @Builder.Default private List<AnswerOption> options = new ArrayList<>();
}