package com.example.entity;
import jakarta.persistence.*;
import lombok.*;
@Entity @Table(name = "quiz_options")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AnswerOption extends BaseEntity {
    @Column(nullable = false, columnDefinition = "text") private String content;
    @Column(name = "is_correct", nullable = false) @Builder.Default private boolean correct = false;
    @Column(nullable = false) @Builder.Default private Integer ordering = 0;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "question_id", nullable = false) private TestQuestion question;
}
