package com.example.entity;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
@Entity @Table(name = "schedule_events")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ScheduleEvent extends BaseEntity {
    @Column(nullable = false, length = 200) private String heading;
    @Column(columnDefinition = "text") private String notes;
    @Column(length = 150) private String place;
    @Column(length = 120) private String speaker;
    @Column(name = "starts_at", nullable = false) private LocalDateTime startsAt;
    @Column(name = "ends_at", nullable = false) private LocalDateTime endsAt;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "owner_id", nullable = false) private UserAccount owner;
}