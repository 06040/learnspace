package com.example.entity;
import com.example.enums.SubmissionState;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
@Entity @Table(name = "submissions")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AssignmentSubmission extends BaseEntity {
    @Column(name = "response_text", columnDefinition = "text") private String responseText;
    @Column(name = "file_url", length = 500) private String fileUrl;
    @Column(name = "earned_points") private Integer earnedPoints;
    @Column(name = "reviewer_comment", columnDefinition = "text") private String reviewerComment;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 20) @Builder.Default private SubmissionState state = SubmissionState.SUBMITTED;
    @Column(name = "submitted_at", nullable = false) private LocalDateTime submittedAt;
    @Column(name = "reviewed_at") private LocalDateTime reviewedAt;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "assignment_id", nullable = false) private Assignment assignment;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "student_id", nullable = false) private UserAccount student;
}
