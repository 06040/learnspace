package com.example.entity;
import com.example.enums.LessonKind;
import jakarta.persistence.*;
import lombok.*;
@Entity @Table(name = "lessons")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Lesson extends BaseEntity {
    @Column(nullable = false, length = 200) private String title;
    @Enumerated(EnumType.STRING) @Column(name = "lesson_type", nullable = false, length = 30) private LessonKind lessonType;
    @Column(name = "content_text", columnDefinition = "text") private String contentText;
    @Column(name = "media_url", length = 500) private String mediaUrl;
    @Column(name = "attachment_url", length = 500) private String attachmentUrl;
    @Column(name = "duration_minutes") private Integer durationMinutes;
    @Column(nullable = false) private Integer ordering;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "module_id", nullable = false) private CourseModule module;
}