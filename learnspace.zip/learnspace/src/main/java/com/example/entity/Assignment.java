package com.example.entity;
import com.example.enums.AssignmentKind;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
@Entity @Table(name = "assignments")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Assignment extends BaseEntity {
    @Column(nullable = false, length = 200) private String title;
    @Column(columnDefinition = "text") private String instructions;
    @Enumerated(EnumType.STRING) @Column(name = "assignment_type", nullable = false, length = 30) private AssignmentKind assignmentType;
    @Column(name = "max_points", nullable = false) @Builder.Default private Integer maxPoints = 100;
    @Column(name = "due_date") private LocalDateTime dueDate;
    @Column(name = "passing_score") private Integer passingScore;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "lesson_id") private Lesson lesson;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "course_id", nullable = false) private Course course;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "author_id", nullable = false) private UserAccount author;
    @OneToMany(mappedBy = "assignment", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default private List<TestQuestion> questions = new ArrayList<>();
}