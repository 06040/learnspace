package com.example.entity;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
@Entity @Table(name = "lesson_progress", uniqueConstraints = @UniqueConstraint(columnNames = {"enrollment_id", "lesson_id"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LessonProgress {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) @Builder.Default private boolean completed = false;
    @Column(name = "watched_seconds") @Builder.Default private Integer watchedSeconds = 0;
    @Column(name = "finished_at") private LocalDateTime finishedAt;
    @Column(name = "updated_at", nullable = false) private LocalDateTime updatedAt;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "enrollment_id", nullable = false) private Enrollment enrollment;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "lesson_id", nullable = false) private Lesson lesson;
    @PrePersist @PreUpdate public void touch() { this.updatedAt = LocalDateTime.now(); }
}