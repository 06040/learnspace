package com.example.dto;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder
public class CourseSummaryDto {
    private Long id;
    private String title;
    private String summary;
    private String coverImage;
    private String category;
    private String difficulty;
    private Integer durationHours;
    private String teacherName;
    private Integer moduleCount;
    private Integer studentCount;
    private LocalDateTime createdAt;
}
