package com.example.dto;
import lombok.*;
import java.util.List;
@Data @Builder
public class CourseDetailDto {
    private Long id;
    private String title;
    private String summary;
    private String description;
    private String coverImage;
    private String category;
    private String difficulty;
    private Integer durationHours;
    private boolean published;
    private TeacherBriefDto teacher;
    private List<ModuleDto> modules;
}
