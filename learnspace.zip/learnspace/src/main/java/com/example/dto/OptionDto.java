package com.example.dto;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class OptionDto {
    private Long id;
    private String content;
    private boolean correct;
    private Integer ordering;
}
