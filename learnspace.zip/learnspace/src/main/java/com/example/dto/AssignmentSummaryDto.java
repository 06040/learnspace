package com.example.dto;
import com.example.enums.AssignmentKind;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class AssignmentSummaryDto {
    private Long id;
    private String title;
    private AssignmentKind assignmentType;
    private Integer maxPoints;
    private LocalDateTime dueDate;
}
