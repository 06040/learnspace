package com.example.dto;
import com.example.enums.SubmissionState;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class SubmissionDto {
    private Long id;
    private Long assignmentId;
    private String assignmentTitle;
    private Long studentId;
    private String studentName;
    private String responseText;
    private String fileUrl;
    private Integer earnedPoints;
    private Integer maxPoints;
    private String reviewerComment;
    private SubmissionState state;
    private LocalDateTime submittedAt;
    private LocalDateTime reviewedAt;
}
