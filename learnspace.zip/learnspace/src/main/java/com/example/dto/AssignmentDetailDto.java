package com.example.dto;
import com.example.enums.AssignmentKind;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class AssignmentDetailDto {
    private Long id;
    private String title;
    private String instructions;
    private AssignmentKind assignmentType;
    private Integer maxPoints;
    private Integer passingScore;
    private LocalDateTime dueDate;
    private String courseTitle;
    private List<QuestionDto> questions;
    private boolean submitted;
    private Integer earnedPoints;
    private String submissionState;
}
