package com.example.dto;
import com.example.enums.EnrollmentState;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class EnrollmentProgressDto {
    private Long enrollmentId;
    private Long courseId;
    private String courseTitle;
    private String coverImage;
    private EnrollmentState status;
    private int totalLessons;
    private int completedLessons;
    private int percent;
    private LocalDateTime enrolledAt;
    private LocalDateTime completedAt;
}
