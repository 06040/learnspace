package com.example.dto;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data public class RegistrationForm {
    @NotBlank @Size(min=3,max=50) private String username;
    @NotBlank @Email private String email;
    @NotBlank @Size(min=6,max=100) private String password;
    @NotBlank private String fullName;
}
