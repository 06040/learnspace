package com.example.dto;
import com.example.enums.QuestionKind;
import lombok.*;
import java.util.List;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class QuestionDto {
    private Long id;
    private String prompt;
    private QuestionKind questionType;
    private Integer points;
    private Integer ordering;
    private List<OptionDto> options;
}
