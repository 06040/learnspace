package com.example.dto;
import lombok.*;
import java.util.List;
import java.util.Map;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class StatisticsDto {
    private long totalStudents;
    private long totalCourses;
    private long totalEnrollments;
    private long completedEnrollments;
    private List<PopularCourseStat> popularCourses;
    private Map<String, Long> submissionsByState;
    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class PopularCourseStat {
        private Long courseId;
        private String title;
        private long enrollments;
    }
}
