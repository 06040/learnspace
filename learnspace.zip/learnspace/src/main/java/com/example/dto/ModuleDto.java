package com.example.dto;
import lombok.*;
import java.util.List;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ModuleDto {
    private Long id;
    private String title;
    private String description;
    private Integer ordering;
    private List<LessonDto> lessons;
}
