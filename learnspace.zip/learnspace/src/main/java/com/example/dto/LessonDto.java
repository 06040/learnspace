package com.example.dto;
import com.example.enums.LessonKind;
import lombok.*;
import java.util.List;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class LessonDto {
    private Long id;
    private String title;
    private LessonKind lessonType;
    private String contentText;
    private String mediaUrl;
    private String attachmentUrl;
    private Integer durationMinutes;
    private Integer ordering;
    private List<AssignmentSummaryDto> assignments;
    private boolean completed;
}
