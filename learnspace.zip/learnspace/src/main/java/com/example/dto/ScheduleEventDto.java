package com.example.dto;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ScheduleEventDto {
    private Long id;
    private String heading;
    private String notes;
    private String place;
    private String speaker;
    private LocalDateTime startsAt;
    private LocalDateTime endsAt;
}
