package com.example.dto;
import lombok.Data;
import java.util.List;
@Data public class QuizAnswerRequest {
    private List<AnswerEntry> answers;
    @Data public static class AnswerEntry {
        private Long questionId;
        private List<Long> selectedOptionIds;
    }
}
