package com.example.dto;
import lombok.*;
import java.util.Set;
@Data @Builder
public class UserSummaryDto {
    private Long id;
    private String username;
    private String email;
    private String fullName;
    private String avatarUrl;
    private Set<String> roles;
}
