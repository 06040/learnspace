package com.example.controller;

import com.example.entity.UserAccount;
import com.example.service.CourseService;
import com.example.service.ScheduleService;
import com.example.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/student")
@RequiredArgsConstructor
public class StudentController {
    private final CourseService courses;
    private final ScheduleService schedules;
    private final UserService users;

    @GetMapping("/dashboard")
    public String dashboard(Authentication authentication, Model model) {
        UserAccount student = users.current(authentication);
        model.addAttribute("user", student);
        model.addAttribute("courses", courses.published());
        model.addAttribute("enrollments", courses.studentEnrollments(student));
        model.addAttribute("schedule", schedules.all());
        return "student/dashboard";
    }

    @PostMapping("/courses/{id}/enroll")
    public String enroll(@PathVariable Long id, Authentication authentication) {
        courses.enroll(users.current(authentication), id);
        return "redirect:/student/dashboard";
    }
}
