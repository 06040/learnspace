package com.example.controller;

import com.example.service.CourseService;
import com.example.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
public class PublicController {
    private final CourseService courses;
    private final UserService users;

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("courses", courses.published());
        return "home";
    }

    @GetMapping("/auth/login")
    public String login() {
        return "auth/login";
    }

    @GetMapping("/auth/register")
    public String register() {
        return "auth/register";
    }

    @PostMapping("/auth/register")
    public String register(@RequestParam String username,
                           @RequestParam String email,
                           @RequestParam String password,
                           @RequestParam String fullName,
                           Model model) {
        try {
            users.registerStudent(username, email, password, fullName);
            return "redirect:/auth/login?registered=true";
        } catch (IllegalArgumentException ex) {
            model.addAttribute("error", ex.getMessage());
            return "auth/register";
        }
    }

    @GetMapping("/auth/access-denied")
    public String accessDenied() {
        return "auth/access-denied";
    }
}
