package com.example.controller;

import com.example.entity.Course;
import com.example.entity.ScheduleEvent;
import com.example.entity.UserAccount;
import com.example.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDateTime;

@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {
    private final CourseService courses;
    private final ScheduleService schedules;
    private final UserService users;
    private final ActivityLogService audit;

    @GetMapping("/dashboard")
    public String dashboard(Authentication authentication, Model model) {
        model.addAttribute("user", users.current(authentication));
        model.addAttribute("courses", courses.all());
        model.addAttribute("schedule", schedules.all());
        model.addAttribute("users", users.all());
        model.addAttribute("logs", audit.latest());
        return "admin/dashboard";
    }

    @GetMapping("/courses/new")
    public String newCourse(Model model) {
        model.addAttribute("course", new Course());
        model.addAttribute("action", "/admin/courses");
        return "teacher/course-form";
    }

    @GetMapping("/courses/{id}/edit")
    public String editCourse(@PathVariable Long id, Model model) {
        model.addAttribute("course", courses.get(id));
        model.addAttribute("action", "/admin/courses/" + id);
        return "teacher/course-form";
    }

    @PostMapping({"/courses", "/courses/{id}"})
    public String saveCourse(@PathVariable(required = false) Long id,
                             @RequestParam String title,
                             @RequestParam(required = false) String summary,
                             @RequestParam(required = false) String description,
                             @RequestParam(required = false) String category,
                             @RequestParam(required = false) String difficulty,
                             @RequestParam(required = false) Integer durationHours,
                             @RequestParam(defaultValue = "false") boolean published,
                             Authentication authentication) {
        UserAccount admin = users.current(authentication);
        courses.save(id, title, summary, description, category, difficulty, durationHours, published, admin, admin);
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/courses/{id}/delete")
    public String deleteCourse(@PathVariable Long id, Authentication authentication) {
        courses.delete(id, users.current(authentication));
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/schedule/new")
    public String newSchedule(Model model) {
        model.addAttribute("event", new ScheduleEvent());
        model.addAttribute("action", "/admin/schedule");
        return "teacher/schedule-form";
    }

    @GetMapping("/schedule/{id}/edit")
    public String editSchedule(@PathVariable Long id, Model model) {
        model.addAttribute("event", schedules.get(id));
        model.addAttribute("action", "/admin/schedule/" + id);
        return "teacher/schedule-form";
    }

    @PostMapping({"/schedule", "/schedule/{id}"})
    public String saveSchedule(@PathVariable(required = false) Long id,
                               @RequestParam String heading,
                               @RequestParam(required = false) String notes,
                               @RequestParam(required = false) String place,
                               @RequestParam(required = false) String speaker,
                               @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime startsAt,
                               @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime endsAt,
                               Authentication authentication) {
        UserAccount admin = users.current(authentication);
        schedules.save(id, heading, notes, place, speaker, startsAt, endsAt, admin, admin);
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/schedule/{id}/delete")
    public String deleteSchedule(@PathVariable Long id, Authentication authentication) {
        schedules.delete(id, users.current(authentication));
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/teachers")
    public String createTeacher(@RequestParam String fullName,
                                @RequestParam String username,
                                @RequestParam String email,
                                @RequestParam String password,
                                Authentication authentication,
                                RedirectAttributes redirectAttributes) {
        try {
            UserAccount admin = users.current(authentication);
            UserAccount teacher = users.createTeacher(username, email, password, fullName, admin);
            redirectAttributes.addFlashAttribute("teacherCreated",
                    "Преподаватель создан: логин " + teacher.getUsername() + ", пароль " + password);
        } catch (IllegalArgumentException ex) {
            redirectAttributes.addFlashAttribute("teacherError", ex.getMessage());
        }
        return "redirect:/admin/dashboard";
    }
}
