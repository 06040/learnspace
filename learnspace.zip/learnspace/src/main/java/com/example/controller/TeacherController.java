package com.example.controller;

import com.example.entity.Course;
import com.example.entity.ScheduleEvent;
import com.example.entity.UserAccount;
import com.example.service.CourseService;
import com.example.service.ScheduleService;
import com.example.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;

@Controller
@RequestMapping("/teacher")
@RequiredArgsConstructor
public class TeacherController {
    private final CourseService courses;
    private final ScheduleService schedules;
    private final UserService users;

    @GetMapping("/dashboard")
    public String dashboard(Authentication authentication, Model model) {
        UserAccount teacher = users.current(authentication);
        model.addAttribute("user", teacher);
        model.addAttribute("courses", courses.byTeacher(teacher));
        model.addAttribute("enrollments", courses.enrollmentsForTeacher(teacher));
        model.addAttribute("schedule", schedules.byOwner(teacher));
        return "teacher/dashboard";
    }

    @GetMapping("/courses/new")
    public String newCourse(Model model) {
        model.addAttribute("course", new Course());
        model.addAttribute("action", "/teacher/courses");
        return "teacher/course-form";
    }

    @GetMapping("/courses/{id}/edit")
    public String editCourse(@PathVariable Long id, Model model) {
        model.addAttribute("course", courses.get(id));
        model.addAttribute("action", "/teacher/courses/" + id);
        return "teacher/course-form";
    }

    @PostMapping({"/courses", "/courses/{id}"})
    public String saveCourse(@PathVariable(required = false) Long id,
                             @RequestParam String title,
                             @RequestParam(required = false) String summary,
                             @RequestParam(required = false) String description,
                             @RequestParam(required = false) String category,
                             @RequestParam(required = false) String difficulty,
                             @RequestParam(required = false) Integer durationHours,
                             @RequestParam(defaultValue = "false") boolean published,
                             Authentication authentication) {
        UserAccount teacher = users.current(authentication);
        courses.save(id, title, summary, description, category, difficulty, durationHours, published, teacher, teacher);
        return "redirect:/teacher/dashboard";
    }

    @PostMapping("/courses/{id}/delete")
    public String deleteCourse(@PathVariable Long id, Authentication authentication) {
        courses.delete(id, users.current(authentication));
        return "redirect:/teacher/dashboard";
    }

    @GetMapping("/schedule/new")
    public String newSchedule(Model model) {
        model.addAttribute("event", new ScheduleEvent());
        model.addAttribute("action", "/teacher/schedule");
        return "teacher/schedule-form";
    }

    @GetMapping("/schedule/{id}/edit")
    public String editSchedule(@PathVariable Long id, Model model) {
        model.addAttribute("event", schedules.get(id));
        model.addAttribute("action", "/teacher/schedule/" + id);
        return "teacher/schedule-form";
    }

    @PostMapping({"/schedule", "/schedule/{id}"})
    public String saveSchedule(@PathVariable(required = false) Long id,
                               @RequestParam String heading,
                               @RequestParam(required = false) String notes,
                               @RequestParam(required = false) String place,
                               @RequestParam(required = false) String speaker,
                               @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime startsAt,
                               @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime endsAt,
                               Authentication authentication) {
        UserAccount teacher = users.current(authentication);
        schedules.save(id, heading, notes, place, speaker, startsAt, endsAt, teacher, teacher);
        return "redirect:/teacher/dashboard";
    }

    @PostMapping("/schedule/{id}/delete")
    public String deleteSchedule(@PathVariable Long id, Authentication authentication) {
        schedules.delete(id, users.current(authentication));
        return "redirect:/teacher/dashboard";
    }
}
