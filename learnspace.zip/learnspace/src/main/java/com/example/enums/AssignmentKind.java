package com.example.enums;

public enum AssignmentKind { QUIZ, PRACTICE, PROJECT, ESSAY }