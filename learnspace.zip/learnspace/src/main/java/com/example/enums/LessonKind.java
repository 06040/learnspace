package com.example.enums;

public enum LessonKind { TEXT, VIDEO, AUDIO, PRESENTATION, INTERACTIVE }