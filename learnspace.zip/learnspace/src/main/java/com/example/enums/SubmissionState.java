package com.example.enums;

public enum SubmissionState { DRAFT, SUBMITTED, REVIEWED, REJECTED }