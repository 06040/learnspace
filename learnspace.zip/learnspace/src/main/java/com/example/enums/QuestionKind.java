package com.example.enums;

public enum QuestionKind { SINGLE_CHOICE, MULTIPLE_CHOICE, TRUE_FALSE }