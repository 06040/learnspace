package com.example.enums;

public enum EnrollmentState { ACTIVE, COMPLETED, PAUSED, DROPPED }