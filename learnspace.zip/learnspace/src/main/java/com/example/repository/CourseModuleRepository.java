package com.example.repository;
import com.example.entity.CourseModule;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface CourseModuleRepository extends JpaRepository<CourseModule, Long> {
    @EntityGraph(attributePaths = "lessons") List<CourseModule> findByCourseIdOrderByOrderingAsc(Long courseId);
    @EntityGraph(attributePaths = "lessons") Optional<CourseModule> findWithLessonsById(Long id);
}