package com.example.repository;
import com.example.entity.ScheduleEvent;
import org.springframework.data.jpa.repository.*;
import java.util.List;
public interface ScheduleEventRepository extends JpaRepository<ScheduleEvent, Long> {
    @EntityGraph(attributePaths = "owner")
    List<ScheduleEvent> findAllByOrderByStartsAtAsc();
    @EntityGraph(attributePaths = "owner")
    List<ScheduleEvent> findByOwnerIdOrderByStartsAtAsc(Long ownerId);
}
