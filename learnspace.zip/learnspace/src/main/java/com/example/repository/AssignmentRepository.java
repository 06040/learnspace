package com.example.repository;
import com.example.entity.Assignment;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface AssignmentRepository extends JpaRepository<Assignment, Long> {
    @EntityGraph(attributePaths = {"author","course","questions.options"}) Optional<Assignment> findFullById(Long id);
    @EntityGraph(attributePaths = "course") List<Assignment> findByCourseId(Long courseId);
}