package com.example.repository;
import com.example.entity.Course;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;
public interface CourseRepository extends JpaRepository<Course, Long> {
    @EntityGraph(attributePaths = {"teacher","modules"}) Optional<Course> findWithModulesById(Long id);
    @EntityGraph(attributePaths = "teacher") List<Course> findAllByOrderByCreatedAtDesc();
    @EntityGraph(attributePaths = "teacher") Page<Course> findByPublishedTrue(Pageable pageable);
    @EntityGraph(attributePaths = "teacher") Page<Course> findByTeacherId(Long teacherId, Pageable pageable);
    @Query("SELECT c FROM Course c WHERE c.published = true AND (LOWER(c.title) LIKE LOWER(CONCAT('%', :q, '%')) OR LOWER(c.category) LIKE LOWER(CONCAT('%', :q, '%')))") Page<Course> searchPublished(@Param("q") String q, Pageable pageable);
    @Query("SELECT c, COUNT(e) FROM Course c LEFT JOIN c.enrollments e WHERE c.published = true GROUP BY c ORDER BY COUNT(e) DESC") List<Object[]> findPopularCourses(Pageable pageable);
}
