package com.example.repository;
import com.example.entity.AssignmentSubmission;
import com.example.enums.SubmissionState;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;
public interface AssignmentSubmissionRepository extends JpaRepository<AssignmentSubmission, Long> {
    @org.springframework.data.jpa.repository.EntityGraph(attributePaths = {"assignment","student"}) List<AssignmentSubmission> findByAssignmentId(Long assignmentId);
    @org.springframework.data.jpa.repository.EntityGraph(attributePaths = {"assignment","student"}) List<AssignmentSubmission> findByStudentId(Long studentId);
    @org.springframework.data.jpa.repository.EntityGraph(attributePaths = {"assignment.course","student"}) Optional<AssignmentSubmission> findByAssignmentIdAndStudentId(Long assignmentId, Long studentId);
    @Query("SELECT s FROM AssignmentSubmission s WHERE s.assignment.author.id = :teacherId AND s.state = :state") List<AssignmentSubmission> findPendingForTeacher(@Param("teacherId") Long teacherId, @Param("state") SubmissionState state);
}