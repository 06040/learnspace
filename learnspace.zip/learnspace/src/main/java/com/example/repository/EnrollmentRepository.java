package com.example.repository;
import com.example.entity.Enrollment;
import org.springframework.data.jpa.repository.*;
import java.util.List;
import java.util.Optional;
public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
    @org.springframework.data.jpa.repository.EntityGraph(attributePaths = {"course","progressEntries"}) Optional<Enrollment> findByStudentIdAndCourseId(Long studentId, Long courseId);
    @org.springframework.data.jpa.repository.EntityGraph(attributePaths = "course") List<Enrollment> findByStudentId(Long studentId);
    @org.springframework.data.jpa.repository.EntityGraph(attributePaths = "student") List<Enrollment> findByCourseId(Long courseId);
    @org.springframework.data.jpa.repository.EntityGraph(attributePaths = {"student", "course"})
    List<Enrollment> findByCourseTeacherIdOrderByCourseTitleAscStudentFullNameAsc(Long teacherId);
}
