package com.example.exception;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(ResourceNotFoundException.class)
    public String notFound(ResourceNotFoundException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/404";
    }
    @ExceptionHandler(IllegalStateException.class)
    public String conflict(IllegalStateException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/general";
    }
    @ExceptionHandler(Exception.class)
    public String general(Exception ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/general";
    }
}
