package com.example.config;
import jakarta.servlet.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;
import java.io.IOException;
import java.util.Set;
@Component
public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {
    @Override public void onAuthenticationSuccess(HttpServletRequest req, HttpServletResponse res, Authentication auth) throws IOException {
        Set<String> r = AuthorityUtils.authorityListToSet(auth.getAuthorities());
        if (r.contains("ROLE_ADMIN")) res.sendRedirect("/admin/dashboard");
        else if (r.contains("ROLE_TEACHER")) res.sendRedirect("/teacher/dashboard");
        else res.sendRedirect("/student/dashboard");
    }
}