package com.example.config;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.cache.CacheManager;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.*;
import java.util.concurrent.TimeUnit;
@Configuration
public class CacheConfig {
    @Bean public CacheManager cacheManager() {
        CaffeineCacheManager mgr = new CaffeineCacheManager("courses","modules","assignments","popular");
        mgr.setCaffeine(Caffeine.newBuilder().maximumSize(500).expireAfterWrite(10, TimeUnit.MINUTES).recordStats());
        return mgr;
    }
}