package com.example.config;

import com.example.entity.*;
import com.example.enums.LessonKind;
import com.example.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.Set;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    private final RoleRepository roles;
    private final UserAccountRepository users;
    private final CourseRepository courses;
    private final ScheduleEventRepository schedules;
    private final PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public void run(String... args) {
        Role studentRole = role("STUDENT");
        Role teacherRole = role("TEACHER");
        Role adminRole = role("ADMIN");

        UserAccount admin = user("admin", "admin@learnspace.local", "Администратор",
                "admin123", Set.of(adminRole, teacherRole, studentRole));
        UserAccount teacher = user("teacher", "teacher@learnspace.local", "Иван Петров",
                "teacher123", Set.of(teacherRole));
        user("student", "student@learnspace.local", "Анна Смирнова",
                "student123", Set.of(studentRole));

        if (courses.count() == 0) {
            Course course = Course.builder()
                    .title("Основы Java и Spring Boot")
                    .summary("Практический курс по созданию веб-приложений на Spring.")
                    .description("Разбор MVC, Security, JPA, Thymeleaf и работы с базой данных на учебном проекте.")
                    .category("Backend")
                    .difficulty("Начальный")
                    .durationHours(24)
                    .published(true)
                    .teacher(teacher)
                    .build();

            CourseModule module = CourseModule.builder()
                    .title("Старт проекта")
                    .description("Настройка окружения, структура проекта, первый контроллер.")
                    .ordering(1)
                    .course(course)
                    .build();
            Lesson lesson = Lesson.builder()
                    .title("Spring MVC и Thymeleaf")
                    .lessonType(LessonKind.TEXT)
                    .contentText("На этом уроке студент знакомится с контроллерами, моделями и шаблонами.")
                    .durationMinutes(45)
                    .ordering(1)
                    .module(module)
                    .build();
            module.getLessons().add(lesson);
            course.getModules().add(module);
            courses.save(course);
        }

        if (schedules.count() == 0) {
            schedules.save(ScheduleEvent.builder()
                    .heading("Вводная лекция по Spring Boot")
                    .notes("Обзор курса, роли пользователей и правила выполнения заданий.")
                    .place("Онлайн")
                    .speaker(teacher.getFullName())
                    .startsAt(LocalDateTime.now().plusDays(1).withHour(18).withMinute(0).withSecond(0).withNano(0))
                    .endsAt(LocalDateTime.now().plusDays(1).withHour(19).withMinute(30).withSecond(0).withNano(0))
                    .owner(teacher)
                    .build());
            schedules.save(ScheduleEvent.builder()
                    .heading("Административная проверка расписания")
                    .notes("Демонстрационное событие, созданное администратором.")
                    .place("Кабинет администратора")
                    .speaker(admin.getFullName())
                    .startsAt(LocalDateTime.now().plusDays(2).withHour(12).withMinute(0).withSecond(0).withNano(0))
                    .endsAt(LocalDateTime.now().plusDays(2).withHour(13).withMinute(0).withSecond(0).withNano(0))
                    .owner(admin)
                    .build());
        }
    }

    private Role role(String name) {
        return roles.findByName(name).orElseGet(() -> roles.save(Role.builder().name(name).build()));
    }

    private UserAccount user(String username, String email, String fullName, String rawPassword, Set<Role> userRoles) {
        return users.findByUsername(username).orElseGet(() -> {
            UserAccount user = UserAccount.builder()
                    .username(username)
                    .email(email)
                    .fullName(fullName)
                    .password(passwordEncoder.encode(rawPassword))
                    .enabled(true)
                    .build();
            user.getRoles().addAll(userRoles);
            return users.save(user);
        });
    }
}
